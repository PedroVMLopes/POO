package Circulo;

import Forma.forma;

public class circulo extends forma{

	public circulo (int coordenadaX, int coordenadaY, double raio) {
		super(coordenadaX, coordenadaY, raio);
	}

	@Override
	public double calcularArea() {
		return 0;
	}
	
}

package Cilindro;

import Forma.forma;
import volume.Volume;

public class cilindro extends forma implements Volume {
	
	public cilindro(int coordenadaX, int coordenadaY, double raio, double altura) {
		super(coordenadaX, coordenadaY, raio);
		this.altura = altura;
	}

	protected double altura;
	

	@Override
	public double calcularArea() {
		return 0;
	}
	
	public double calcularVolume() {
		double aux = 0;
		return aux;
	}


}

package volume;

public interface Volume {
	
	public abstract double calcularVolume();

}

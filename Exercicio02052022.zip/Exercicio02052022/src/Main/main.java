package Main;

import Cilindro.cilindro;
import Circulo.circulo;
import Forma.forma;
import volume.Volume;

public class main {

	public static void main(String[] args) {

		forma[] forma = new forma[4];
		
		forma[0] = new circulo(10, 5, 2);
		forma[1] = new circulo(15, 10, 3);
		forma[2] = new cilindro(20, 15, 2, 5);
		forma[3] = new cilindro(25, 20, 3, 10);
		
		
		// Imprimir a �rea de cada objeto	
		for (forma f : forma) {
			System.out.println(f.calcularArea());
		}
		
		
		// Imprimir o volume dos objetos
		for(forma f : forma) {
			if(f instanceof Volume) {
				System.out.println(((Volume) f).calcularVolume());
			}
		}
		
		
	}

}


public class Vendedor {

	private double totalDasVendas;
	private double comissao;
	
	public Vendedor(String nome, String cpf, String matricula, double totalDasVendas, double comissao) {
		super();
		this.totalDasVendas = totalDasVendas;
		this.comissao = comissao;
	}
	
	
	
}

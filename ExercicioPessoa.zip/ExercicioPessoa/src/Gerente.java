
public class Gerente {
	
	private double salario;
	private double bonus;
	
	
	public Gerente(String nome, String cpf, String matricula, double salario, double bonus) {
		super();
		this.salario = salario;
		this.bonus = bonus;
	}
	
	

}

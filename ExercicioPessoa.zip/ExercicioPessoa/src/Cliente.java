
public class Cliente {
	
	private double valorDaDivida;

	public Cliente(String nome, double valorDaDivida) {
		super();
		this.valorDaDivida = valorDaDivida;
	}
	
	

}

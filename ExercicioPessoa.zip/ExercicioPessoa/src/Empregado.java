
public class Empregado {
	
	protected String matricula;

	public Empregado(String nome, String cpf, String matricula) {
		super();
		this.matricula = matricula;
	}
	
	

}

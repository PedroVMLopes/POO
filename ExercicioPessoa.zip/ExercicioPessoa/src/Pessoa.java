
public class Pessoa {
	
	protected String nome;
	protected String cpf;
	
	
	public Pessoa(String nome, String cpf) {
		super();
		this.nome = nome;
		this.cpf = cpf;
	}


	@Override
	public String toString() {
		String aux = "";
		aux += "Nome: " + nome ;
		aux +=  ", CPF: " + cpf;
		return aux;
	}


	public String getCpf() {
		return cpf;
	}

	
	
}


public interface Salario {
	
	public abstract double calcularSalario();

}

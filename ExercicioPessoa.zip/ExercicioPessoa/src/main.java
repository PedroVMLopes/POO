
public class main {

	public static void main(String[] args) {

		Controle controle = new Controle();
		controle.menuPrincipal();
		
	}

}

package br.fiap.aluno;

public class AlunoFundamental extends Aluno{

	// Atributo espec�fico da classe
	private int serie;
	
	// M�todo para calcular e retornar a m�dia
	public double calcularMedia() {
		double media = (prova1 + prova2)/2;
		return media;
	}
	
}

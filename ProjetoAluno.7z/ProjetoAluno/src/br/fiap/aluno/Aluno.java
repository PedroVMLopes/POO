package br.fiap.aluno;

public abstract class Aluno {
// O modificador Abstract pro�be a cria��o de objetos a partir dessa classe

	// Atributos que ser�o compartilhados com as subclasses
	private long rm;
	private String nome;
	protected double prova1;
	protected double prova2;
	
	
	
}

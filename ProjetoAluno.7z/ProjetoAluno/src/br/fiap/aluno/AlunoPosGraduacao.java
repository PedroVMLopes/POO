package br.fiap.aluno;

public class AlunoPosGraduacao extends Aluno {

}

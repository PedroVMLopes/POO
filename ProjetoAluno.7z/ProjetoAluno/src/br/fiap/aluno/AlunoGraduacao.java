package br.fiap.aluno;

public class AlunoGraduacao extends Aluno{
	
	// Atributos espec�ficos
	private String curso;
	private double trabalho;

}

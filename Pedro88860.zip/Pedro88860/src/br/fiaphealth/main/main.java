package br.fiaphealth.main;


import br.fiaphealth.consulta.Consulta;
import br.fiaphealth.medico.Medico;
import br.fiaphealth.paciente.Paciente;

public class main {
	
	public static void main(String[] args) {

		Consulta[] consulta = new Consulta[4];
		Medico medico = new Medico(2, "Dr�uzio", "Cardiologia", 40);
		Paciente paciente = new Paciente("123", "Jorge", "011");
		Paciente paciente2 = new Paciente("456", "Fernando", "021");
		Paciente paciente3 = new Paciente("456", "Fernando", "021");
		
		
		consulta[0] = new Consulta("20/05/2022", paciente, medico);
		consulta[1] = new Consulta("21/05/2022", paciente2, medico);
		consulta[2] = new Consulta("22/05/2022", paciente2, medico);
		consulta[3] = new Consulta("23/05/2022", paciente, medico);
		
		
		System.out.println("Paciente: \n" + paciente.getDados());
		System.out.println("M�dico: \n" + medico.getDados());
		System.out.println("Consulta: \n" + consulta[0].getDados() + "\n");
		System.out.println("Consulta: \n" + consulta[1].getDados() + "\n");
		System.out.println("Consulta: \n" + consulta[2].getDados() + "\n");
		System.out.println("Consulta: \n" + consulta[3].getDados() + "\n");
		
	
	}
}

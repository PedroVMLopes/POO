package br.fiaphealth.medico;

public class Medico {

	private int crm;
	private String nome;
	private String especialidade;
	private int total;
	
	
	public Medico(int crm, String nome, String especialidade, int total) {
		super();
		this.crm = crm;
		this.nome = nome;
		this.especialidade = especialidade;
		this.total = total;
	}


	public String getDados() {
		String aux = "";
		aux += "CRM: " + crm + "\n";
		aux += "Nome: " + nome + "\n";
		aux += "Especialidade: " + especialidade + "\n";
		aux += "Total de Consultas: " + total + "\n";
		return aux;
	}
	
}

package br.fiaphealth.consulta;

import br.fiaphealth.medico.Medico;
import br.fiaphealth.paciente.Paciente;

public class Consulta {

	private String data;
	private Paciente paciente;
	private Medico medico;
	
	public Consulta(String data, Paciente paciente, Medico medico) {
		super();
		this.data = data;
		this.paciente = paciente;
		this.medico = medico;
	}

	public Consulta(Paciente paciente, Medico medico) {
		super();
		this.paciente = paciente;
		this.medico = medico;
		this.data = "25/04/2022";
	}
	
	public String getDados() {
		String aux = "";
		aux += "Data: " + data + "\n";
		aux += "Paciente: " + paciente + "\n";
		aux += "M�dico: " + medico + "\n";
		return aux;
	}
	
	public void setDados(String data) {
		this.data = data;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}

	public void setMedico(Medico medico) {
		this.medico = medico;
	}
	
	
	
	
	
}

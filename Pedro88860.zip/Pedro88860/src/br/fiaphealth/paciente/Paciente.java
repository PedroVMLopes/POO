package br.fiaphealth.paciente;

public class Paciente {

	private String cpf;
	private String nome;
	private String fone;
	
	public Paciente(String cpf, String nome, String fone) {
		super();
		this.cpf = cpf;
		this.nome = nome;
		this.fone = fone;
	}

	public String getDados() {
		String aux = "";
		aux += "CPF: " + cpf + "\n";
		aux += "Nome: " + nome + "\n";
		aux += "Fone: " + fone + "\n";
		return aux;
	}
	
	
}

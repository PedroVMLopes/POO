package br.programa50.pessoa;

public class Pessoa {
	
	protected static String nome;
	protected static double pretencaoSalarial;
	protected static String especializacao;
	
	
	public Pessoa(String nome, double pretencaoSalarial, String especializacao) {
		this.nome = nome;
		this.pretencaoSalarial = pretencaoSalarial;
		this.especializacao = especializacao;
	}
	
	public String toString() {
		String aux = "";
		aux += "Nome: " + nome;
		aux += "Preten��o salarial: " + pretencaoSalarial;
		aux += "Especializa�ao: " + especializacao;
		return aux;
	}
	




}

package br.programa50.pessoa;

import javax.swing.JOptionPane;

import br.programa50.vaga.Vaga;

public class PessoaJuridica extends Pessoa{
	
	private static String cnpj;
	

	public PessoaJuridica(String nome, double pretencaoSalarial, String especializacao, String cnpj) {
		super(nome, pretencaoSalarial, especializacao);
		this.nome = nome;
		this.pretencaoSalarial = pretencaoSalarial;
		this.especializacao = especializacao;
		this.cnpj = cnpj;
	}
	
	
	public String toString(String nome, double pretencaoSalarial, String especializacao, String cnpj) {
		String aux = "";
		aux += "Nome: " + nome;
		aux += "Preten��o salarial: " + pretencaoSalarial;
		aux += "Especializa�ao: " + especializacao;
		aux += "CNPJ: " + cnpj;
		return aux;
		
	}
	
	
	public static void cadastrarPessoaJuridica() {
		
		nome = JOptionPane.showInputDialog(null, "Digite o nome do candidato");
		pretencaoSalarial = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a preten��o salarial do candidato"));
		especializacao = JOptionPane.showInputDialog(null, "Digite a especializa��o");
		cnpj = JOptionPane.showInputDialog(null, "Digite o CPF do candidato");
		
		PessoaJuridica pessoaJuridica = new PessoaJuridica(nome, pretencaoSalarial, especializacao, cnpj);
		
		JOptionPane.showMessageDialog(null, "Pessoa F�sica cadastrada: " + pessoaJuridica);
		
	}
	
	
	public static void exibirOportunidadeCnpj(String cnpj) {
		
		if(Vaga.getFuncao() == especializacao) {
			JOptionPane.showMessageDialog(null, "Oportunidades dispon�veis" + Vaga.getFuncao());
		}
		
	}

}

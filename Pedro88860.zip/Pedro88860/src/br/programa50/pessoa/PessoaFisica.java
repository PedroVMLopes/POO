package br.programa50.pessoa;

import javax.swing.JOptionPane;

import br.programa50.vaga.Vaga;

public class PessoaFisica extends Pessoa {
	
	private static String cpf;
	

	public PessoaFisica(String nome, double pretencaoSalarial, String especializacao, String cpf) {
		super(nome, pretencaoSalarial, especializacao);
		this.nome = nome;
		this.pretencaoSalarial = pretencaoSalarial;
		this.especializacao = especializacao;
		this.cpf = cpf;
	}
	
	
	public void toString(String nome, double pretencaoSalarial, String especializacao, String cpf) {
		String aux = "";
		aux += "Nome: " + nome;
		aux += "Preten��o salarial: " + pretencaoSalarial;
		aux += "Especializa�ao: " + especializacao;
		aux += "CPF: " + cpf;
		
	}
	
	public static void cadastrarPessoaFisica() {
		
		nome = JOptionPane.showInputDialog(null, "Digite o nome do candidato");
		pretencaoSalarial = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a preten��o salarial do candidato"));
		especializacao = JOptionPane.showInputDialog(null, "Digite a especializa��o");
		cpf = JOptionPane.showInputDialog(null, "Digite o CPF do candidato");
		
		PessoaFisica pessoaFisica = new PessoaFisica(nome, pretencaoSalarial, especializacao, cpf);
		
		JOptionPane.showMessageDialog(null, "Pessoa F�sica cadastrada: " + pessoaFisica);
	}
	
	public static void exibirOportunidadeCpf(String cpf) {
		
		if(Vaga.getFuncao() == especializacao) {
			JOptionPane.showMessageDialog(null, "Oportunidades dispon�veis" + Vaga.getFuncao());
		}
		
	}
	

}

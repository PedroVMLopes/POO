package br.programa50.main;

import javax.swing.JOptionPane;

import br.programa50.pessoa.Pessoa;
import br.programa50.pessoa.PessoaFisica;
import br.programa50.pessoa.PessoaJuridica;
import br.programa50.vaga.*;

public class Main {

	public static void main(String[] args) {
		
		int opc = 0;
		
		//JOptionPane.showMessageDialog(null, "Escolha uma op��o: \n 1. Cadastrar vaga \n 2. Cadastrar candidato \n 3. Exibir oportunidade \n 4. Finalizar", "Input", 3);
		try {
			if(opc == 0) {
			opc = Integer.parseInt(JOptionPane.showInputDialog(null, "Escolha uma op��o: \n 1. Cadastrar vaga \n 2. Cadastrar candidato \n 3. Exibir oportunidade \n 4. Finalizar", "Input", 3));		
				switch (opc) {
				case 1: 
					Vaga.cadastrarVaga();
					opc = 0;
					break;
				case 2:
					int aux = Integer.parseInt(JOptionPane.showInputDialog(null, "1. Pessoa F�sica \n 2. Pessoa Jur�dica", "Digite a op��o de cadastro", 1));
					if(aux == 1) {
						PessoaFisica.cadastrarPessoaFisica();
					}else {
						PessoaJuridica.cadastrarPessoaJuridica();
					}
					opc = 0;
					break;
				case 3:
					int aux2 = Integer.parseInt(JOptionPane.showInputDialog(null, "1. Pessoa F�sica \n 2. Pessoa Jur�dica", "Digite a op��o de cadastro", 1));
					if(aux2 == 1) {
						String cpf = JOptionPane.showInputDialog(null, "Digite o CPF do candidato");
						PessoaFisica.exibirOportunidadeCpf(cpf);
					}else {
						String cnpj = JOptionPane.showInputDialog(null, "Digite o CNPJ do candidato");
						PessoaJuridica.exibirOportunidadeCnpj(cnpj);
					}
					opc = 0;
					break;
				case 4:
					JOptionPane.showMessageDialog(null, "Obrigado por utilizar o programa :)");
					break;
				}
			}
		}catch(NumberFormatException e){
			JOptionPane.showMessageDialog(null, "Op��o Inv�lida!");
		}
		
		
		
	}
	



	
	


}

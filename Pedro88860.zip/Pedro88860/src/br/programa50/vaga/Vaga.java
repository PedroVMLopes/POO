package br.programa50.vaga;

import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Vaga {
	
	private static String funcao;
	private double salario;
	
	
	public Vaga(String funcao, double salario) {
		this.setFuncao(funcao);
		this.salario = salario;
		
	}
	
	public String toString() {
		String aux = "";
		aux += "Fun��o: " + getFuncao();
		aux += "Sal�rio: " + salario;
		return aux;
	}
	
	public static int cadastrarVaga() {
		double salario = 0;
		String funcao = null;
		
		funcao = JOptionPane.showInputDialog(null, "Digite a fun��o da vaga");
		salario = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o sal�rio da vaga"));

		Vaga vaga = new Vaga(funcao, salario);
	
		JOptionPane.showMessageDialog(null, "Vaga cadastrada: " + vaga);
		int opc = 0;
		return opc;
			
	}

	public static String getFuncao() {
		return funcao;
	}

	public void setFuncao(String funcao) {
		this.funcao = funcao;
	}

}

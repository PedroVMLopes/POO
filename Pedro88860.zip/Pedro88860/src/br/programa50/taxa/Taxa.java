package br.programa50.taxa;

public interface Taxa {
	
	public static double calcularTaxa(double valor) {
		double x = valor *0.6;
		return x;
	}

}

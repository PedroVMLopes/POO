package br.fiap.funcionario;

import br.fiap.cargo.Cargo;

public class Funcionario {
	
	private static String nome;
	private static double salario;
	private static Cargo cargo;
	
	public Funcionario(String nome, double salario, Cargo cargo) {
		this.nome = nome;
		this.salario = salario;
		this.cargo = cargo;
		
	}

	public static String getNome() {
		return nome;
	}

	public static void setNome(String nome) {
		Funcionario.nome = nome;
	}

	public static double getSalario() {
		return salario;
	}

	public static void setSalario(double salario) {
		Funcionario.salario = salario;
	}

	public static Cargo getCargo() {
		return cargo;
	}

	public static void setCargo(Cargo cargo) {
		Funcionario.cargo = cargo;
	}

	
	public String toString() {
		return "Funcionario []";
	}
	
	
	
	
	


}

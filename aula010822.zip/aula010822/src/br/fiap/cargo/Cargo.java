package br.fiap.cargo;

import br.fiap.comissao.Comissao;

public enum Cargo implements Comissao{
	
	// Associação de um método na criação da variável final
	// Esse processo facilita possíveis fururas alterações
	
	ATENDENTE {
		public double calcularComissao(double valor) {
			return valor * 0.10;
		}
	}, 
	
	VENDEDOR{
		public double calcularComissao(double valor) {
			return (valor * 0.15) + 5;
		}
	}, 
	GERENTE{
		public double calcularComissao(double valor) {
			return (valor * 0.20) + 10;
		}
	};
	
	

}
